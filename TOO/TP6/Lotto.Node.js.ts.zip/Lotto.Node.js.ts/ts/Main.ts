import Lotto from "./Lotto";
import Lotto_ from "./Lotto_";

(function Main() {
    // const l = new Lotto();
    // l.draw();
    // console.clear();
    // console.info(l.result());
    const l_ = new Lotto_();
    // l_.draw();
    l_.draw_();
    console.clear();
    console.info(l_.result);
})();



